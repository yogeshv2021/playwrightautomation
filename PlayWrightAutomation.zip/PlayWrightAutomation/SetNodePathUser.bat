@echo off
REM Non-admin ways to prefer Node 18
REM 1) Temporary for current Command Prompt session:
REM    Open cmd.exe (not as admin) and run:
REM    set PATH=D:\node-v18.20.4\node-v18.20.4-win-x64;%PATH%
REM    then verify: where node & node -v

REM 2) Temporary for current PowerShell session:
REM    Open PowerShell and run:
REM    $env:Path = 'D:\node-v18.20.4\node-v18.20.4-win-x64;' + $env:Path
REM    then verify: where.exe node; node -v

REM 3) Persistent (per-user) without admin -- writes to user environment
REM    Note: system PATH entries come from SYSTEM variables; if a System-installed
REM    Node appears earlier, a per-user change may not always take precedence
REM    for all programs. Launching apps from a shell with the modified PATH
REM    ensures they inherit your preferred Node.
REM    Run (cmd):
REM    setx PATH "D:\node-v18.20.4\node-v18.20.4-win-x64;%PATH%"
REM    Then close and reopen shells (or log off/on). To make VS Code use it,
REM    start VS Code from a shell where PATH is updated (see below).

REM 4) Start VS Code from an updated shell (no admin needed)
REM    In PowerShell (temporary change + launch):
REM    $env:Path = 'D:\node-v18.20.4\node-v18.20.4-win-x64;' + $env:Path
REM    Start-Process "code" -ArgumentList '.'

REM 5) Alternative: create a per-user 'bin' folder and a small node launcher
REM    - mkdir %USERPROFILE%\bin
REM    - create %USERPROFILE%\bin\node.cmd with:
REM        @echo off
REM        D:\node-v18.20.4\node-v18.20.4-win-x64\node.exe %%*
REM    - Add %USERPROFILE%\bin to your PATH for the current shell:
REM        set PATH=%USERPROFILE%\bin;%PATH%
REM    This makes the shim `node` run your Node 18 binary for that shell.

echo Created non-admin instructions. Use the commands above in your shell.
pause
