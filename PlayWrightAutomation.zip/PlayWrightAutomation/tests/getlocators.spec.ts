
import { test, expect, Locator } from '@playwright/test';

test("verify locators",async ({page})=>{
    await page.goto("https.//demmo.nopcommerce.com");
    //to find interactive elements with alt attribute
    const logo:Locator =  page.getByAltText("nopCommerce demo store");
    //to check visisbility of the element
    await expect(logo).toBeVisible();
    //to find non iteractive elements with no attribute
    await expect(page.getByText(/Welcome\s+to\s+Store/i)).toBeVisible();

    //roles is not an attribute.interactive elements lke button,checkboxes.
    //explicit tag and roles are different.
    //implicit tag and roles are same.

    
    page.getByRole("checkbox",);
    page.getByRole("button",);
    await page.getByRole("link",{name:"register"}).click();
    await expect(page.getByRole("heading",{name:"Register"})).toBeVisible();

    //ideal for form fields
    await page.getByLabel("First Name").fill("yogesh");
    await page.getByLabel("Last Name").fill("v");
    await page.getByLabel("Email").fill('a@gmail.com');

    //#placeholder text
    await page.getByPlaceholder("Search store").fill("Pro");

    //getBytitle
    await expect(page.getByTitle("Home page Link")).toHaveText("Home");

    

    











});