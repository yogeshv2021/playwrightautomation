
let a=5;
let b=10;
const c=20;

let marks = Array(5);

marks[0]=10;

for (let i=0;i<marks.length;i++){
    marks[i]=10;
}

marks.push(60);
marks.unshift(13);
let m1 =marks.indexOf(60);
let m2=marks.includes(60);
let m3=marks.slice(2,7);

let sum=0;
let total = marks.reduce((sum,mark)=>sum+mark,0);
var scores=[90,3,5,40];
var a1 = [];
a1=scores.filter(score=>score%2==0).map(score=>score*3).reduce((sum,score)=>sum+score,0);
let a2 = scores.sort((a,b)=>a-b);

let sumofnums= (a,b)=>a+b;
let a3=sumofnums(2,4);

let day='tuesday';
let d1 = day.slice(0,4);
let d2 = day.split("s");

let date='20';
let nextdate='22';

let diff = parseInt(nextdate) - parseInt(date)

let q1 = day + " is friday";
let q2 = q1.indexOf("d");
let count=0;

while(q2!=-1){
   count++;
   q2=q1.indexOf("d",q2+1);
}


let person={
    'firstname': 'Hari',
    'lastname' : 'se',
    'age': 24,
     fullname: function(){
        return this.firstname+ this.lastname;
    }
    

}

//object is collection of properties

person.firstname = 'sathish';
person.gender ='male';


let a10 = [10,2,3,40,50];

let d = a10.reduce((sum,total)=>sum+total,0);

let a11=a10.sort((a,b)=>a-b);


let productPrices=[100,20,30,40,50];

let discountedPrices = productPrices.map(a=>(a-a*(10/100)));
let affordableProducts = productPrices.filter(a=>a<50);
let gettotal = affordableProducts.reduce((sum,total)=>sum+total,0);