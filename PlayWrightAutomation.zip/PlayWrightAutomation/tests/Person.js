const Student = require("../tests/Students.js");
class Pet extends Students
{

    get location(){
        return "bluecross";
    }
  
  //constructor method
  constructor(firstname,lastname){
    super(firstname,lastname);
  }

  
}

let pet= new Pet("laber","dog");

