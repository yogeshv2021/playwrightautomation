module.exports = class Students
{

  get location(){
    return "canada";
  }
  //constructor method
  constructor(firstname,lastname){
    this.firstname=firstname;
    this.lastname=lastname;
  }

  fullname(){
    return this.firstname +this.lastname;
  }
}

let Student= new Students("sat","ish");
let s2 = Student.fullname();
console.log(s2);