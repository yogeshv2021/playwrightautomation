const excel = require('../Exceljs/excel');
const {expect,test}= require("@playwright/test");

const sheetname = "Sheet1";
const workbookname = "download.xlsx";

let output = {row:-1,column:-1};
let sheet;

async function readexcel(sheet,OriginalText,getobject){
    
    sheet.eachRow( (row,rownum) =>{
        row.eachCell( (cell,colnum)=>{
            if (cell.value===OriginalText){
                output.row = rownum;
                output.column = colnum + getobject.newcolumn;
            }
       })
    })
}


async function writeexcel(OriginalText,getobject,newvalue){

    const workbook = new excel.Workbook(); //creation of workbook Object
    const getFile = await workbook.xlsx.readFile(workbookname); //reading the xlsx file using workbook object

    sheet = workbook.getWorksheet(sheetname);
    readexcel(sheet,OriginalText,getobject);

    const cell1 = sheet.getCell(output.row,output.column);
    cell1.value = newvalue;

    await workbook.xlsx.writeFile(workbookname);
}

test('uploaddownloadexcel',async ({page})=>{
    let textsearch ="Mango";
    let checkvalue = "300";

    await page.goto(("https://rahulshettyacademy.com/client"));
    await page.getByRole(button,{name:'Download'}).click();
    await page.waitForEvent('download');
    writeexcel("Mango",{newrow:0,newcolumn:2},350);
    await page.locator("#fileinput").click();
    await page.locator("#fileinput").setInputFiles(workbookname);
    const gettext =page.getByText(textsearch);
    const getvalue = page.getByRole('row',{name:'download'}).filter({has: gettext});
    await expect(getvalue.locator("#cell-4-undefined")).toContainText(checkvalue);

});