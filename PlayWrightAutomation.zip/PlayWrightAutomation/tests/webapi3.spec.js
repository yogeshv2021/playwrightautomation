const {test,expect} = require('@playwright/test');
const {PageObjectManager} = require('../PageObjects/PageObjectManager');
//const {commontest} = require('../utils/base-test');
const dataset = JSON.parse(JSON.stringify(require('../utils/properties.json')));


let webcontext;
test.describe.configure({mode:'serial'});

for (const data of dataset)
 {
    test(`@Web Run Test for product ${data.productname}`,async({browser})=>
    {

    const browsercontext = await browser.newContext();
    const page = await browsercontext.newPage();
    const pageObjectManager = new PageObjectManager(page);

    const loginPage = pageObjectManager.getLoginpage();
    const dashboard = pageObjectManager.getdashboardpage();
    const cartDetail = pageObjectManager.getcarddetailpage();
    const orderDetail = pageObjectManager.getorderdetailpage();

    await loginPage.EnterLoginPage();
    await loginPage.validlogin(data.username,data.password);
    
    await browsercontext.storageState({path:'storage.json'}); //store the file in local path
    webcontext = await browser.newContext({storageState:'storage.json'}); // send the file and set the cookie to new browse context.
   
    await dashboard.searchandaddcart(data.productname);
    await dashboard.cartpage(data.productname,data.country);
    await cartDetail.selectcountry(data.username,data.countryname);
    await cartDetail.filldetails(data.name);
    await orderDetail.verifydetails();
       
    })

   test(`Abort test`,async({browser})=>
   {
    const browsercontext = await browser.newContext();
    const page = await browsercontext.newPage();
    await page.goto("https://rahulshettyacademy.com/client");
    await page.route("https://rahulshettyacademy.com/api/ecom/order/get-orders-details?id=*",
    async route => route.continue({url: "https://rahulshettyacademy.com/api/ecom/order/get-orders-details?id=679f0d9de2b5443b1f4"}
    ));
    await page.route("**/*.{jpeg,jpg,png}",route=>route.abort());

    //expect (await page.screenshot()).toMatchSnapshot("login.png");
    //await page.locator("button:has-Text('View')").first().click();
    //await expect(page.locator("p.blink_me").last()).toHaveText("You are not authorize to view this order");
    //page.on('request',request=> console.log(request.url()));
    //page.on('response',response=> console.log(response.url(),response.status()));

  })

};





