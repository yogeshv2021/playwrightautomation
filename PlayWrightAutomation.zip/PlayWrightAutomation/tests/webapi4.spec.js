const {test,expect} = require('@playwright/test');
let webcontext;

test.beforeAll("Precondition",async({browser})=>{

    const browsercontext = await browser.newContext();
    const page = await browsercontext.newPage();
    await page.goto("https://rahulshettyacademy.com/client");
    await page.locator("#userEmail").fill("vyoesh@gmail.com");
    await page.locator("#userPassword").fill("Test@123");
    await page.locator("[type='submit']").click();
    await page.waitForLoadState('networkidle');

    await browsercontext.storageState({path:'storage.json'}); //store the file in local path
    webcontext = await browser.newContext({storageState:'storage.json'}); // send the file and set the cookie to new browse context.
    
    await page.locator(".card-body b").first().waitFor;//waiting for element to be displayed
    const content = await page.locator(".card-body b").allTextContents(); // to get the contents
})




test('page Playwright test',async ()=>{

        let productname = 'IPHONE 13 PRO';

        const page = await webcontext.newPage();
        await page.goto("https://rahulshettyacademy.com/client");

        let body = {data: [],message:"No Product in Cart"}
        let bodystring = JSON.stringify(body);
        let response=null;

        await page.route("https://rahulshettyacademy.com/api/ecom/user/get-cart-count/*",async route => {
            response = await page.request.fetch(route.request());
            route.fulfill(
                {
                response,
                bodystring,
                });
        });

        console.log(response);

        let products = page.locator(".card-body");
        await page.locator(".card-body b").first().waitFor;//waiting for element to be displayed
        const content = await page.locator(".card-body b").allTextContents(); // to get contents

        let pcount = await products.count();
        for (let i=0;i<pcount;i++)
            {
             if (await products.nth(i).locator("b").textContent()===productname)
                {
                    await products.nth(i).locator("text= Add To Cart").click();
                    break;
                };
            };

        await page.locator("[routerlink*='cart']").click();
        await page.locator("div li").first().waitFor();
        expect (await page.locator("h3:has-text('IPHONE 13 PRO')").isVisible()).toBeTruthy();
        await page.locator("[type='button']").nth(1).click();
        await page.locator("[placeholder*='Country']").pressSequentially("ind");
        const dropdown= page.locator(".ta-results");
        await dropdown.waitFor();
        const options = await dropdown.locator("button").count();
        
        for (let i=0;i<options;i++){
            let text=await dropdown.locator("button").nth(i).textContent();
            console.log(text);
            if (text.trim()==="India"){
                await dropdown.locator("button").nth(i).click();
                break;
            }
        }
    
        await expect ( page.locator(".user__name [type='text']").first()).toHaveText("vyoesh@gmail.com");
        
        await page.locator('input.input.txt').nth(1).fill("503");
        await page.locator('input.input.txt').nth(2).fill("yogesh");
        await page.locator("[name='coupon']").fill("Coupon");
    
        const getexpirydate =page.locator('select.input');
        await getexpirydate.nth(0).selectOption("04");
        await getexpirydate.nth(1).selectOption("26");
       
    
        await page.locator('.action__submit').click();
    
        await expect (page.locator(".hero-primary")).toHaveText(" Thankyou for the order. ");
        const getorderid= await page.locator(".em-spacer-1 .ng-star-inserted").textContent();
        
    
        let newgetorderid = getorderid.split("|")[1].trim();
        console.log(newgetorderid);
    
        await page.locator(".em-spacer-1 [routerlink*='myorders']").click();
        const getviews = page.locator("tbody tr");
        const countview = await getviews.count();
        
        for(let i=0;i<countview;i++){
            if (await getviews.nth(i).locator("th").textContent()===newgetorderid){
                const getviewss = getviews.nth(i).locator("button").first();
                await getviewss.click();
                break;
            }
        }
        
   
})


test.afterAll("run test",async()=>{

    const page = await webcontext.newPage();
    await page.goto("https://rahulshettyacademy.com/client");
    await page.route("https://rahulshettyacademy.com/api/ecom/order/get-orders-details?id=*",
    route => route.continue({url: "https://rahulshettyacademy.com/api/ecom/order/get-orders-details?id=679f0d9de2b5443b1f434f0b"}
    ));
    await page.locator("button:has-Text('View')").first().click();
   // await expect(page.locator("p.blink_me").last()).toHaveText("You are not authorize to view this order");
    await page.route("**/*.{jpeg,jpg,png}",route=>route.abort());

    page.on('request',request=> console.log(request.url()));
    page.on('response',response=> console.log(response.url(),response.status()));

})

test("run test",async()=>{

    const page = await webcontext.newPage();
    await page.goto("https://rahulshettyacademy.com/client");
    await page.route("https://rahulshettyacademy.com/api/ecom/order/get-orders-details?id=*",
         async route => route.continue({url: "https://rahulshettyacademy.com/api/ecom/order/get-orders-details?id=679f0d9de2b5443b1f4"}
    ));
    await page.route("**/*.{jpeg,jpg,png}",route=>route.abort());

    //expect (await page.screenshot()).toMatchSnapshot("login.png");
    //await page.locator("button:has-Text('View')").first().click();
    //await expect(page.locator("p.blink_me").last()).toHaveText("You are not authorize to view this order");
    //page.on('request',request=> console.log(request.url()));
    //page.on('response',response=> console.log(response.url(),response.status()));

    page.waitForSelector('#username',{state:'visible',timeout:5000});
    page.fill('#username','playwirght_user');
    page.waitForTimeout(3000);
    page.getByText('Success',{timeout: 5000}).isVisible();
    page.waitForLoadState('networkidle');
    


})