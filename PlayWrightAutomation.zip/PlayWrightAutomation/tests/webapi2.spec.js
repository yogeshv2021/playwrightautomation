const { test, request } = require("@playwright/test");
const { AuthUtils } = require("../utils/AuthUtils");

const orderpayload= {orders:[{country:"India",productOrderedId:"6701364cae2afd4c0b90113c"}]}

const loginheader = {"Content-Type": "application/json"};
const header = {"Authorization": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NzdhM2Y5MWUyYjU0NDNiMWYxMzZiNDkiLCJ1c2VyRW1haWwiOiJ2eW9lc2hAZ21haWwuY29tIiwidXNlck1vYmlsZSI6OTc5MDkxOTM0NCwidXNlclJvbGUiOiJjdXN0b21lciIsImlhdCI6MTczODQzMjAxMywiZXhwIjoxNzY5OTg5NjEzfQ.yoUKgs7riLqpi3YY86QHLAbUQ2pXdmDdCU4W0s9kkWY","Content-Type": "application/json"};
const login = {userEmail: 'vyoesh@gmail.com', userPassword: 'Test@123'};

const token="123";
let newgetorderid;

//Login ApI
test.beforeAll(async()=>{
    const apicontext = await request.newContext();
    const authUtil = new AuthUtils(apicontext,login,orderpayload,loginheader,header);
    const response = await authUtil.createOrder();
    //console.log (response.token);
});

test('Order',async ({page})=>{
    let productname = 'IPHONE 13 PRO';
    let products = page.locator(".card-body");
    page.addInitScript(value=>{
        window.localStorage.setItem("token",value);
    },token);

    await page.locator(".card-body b").first().waitFor;
    const content = await page.locator(".card-body b").allTextContents();
    const getviews = page.locator("tbody tr");
    const countview = await getviews.count();

    
    
    for(let i=0;i<countview;i++){
        if (await getviews.nth(i).locator("th").textContent()===newgetorderid){
            const getviewss = getviews.nth(i).locator("button").first();
            await getviewss.click();
            break;
        }
    }

    page.pause();
});



