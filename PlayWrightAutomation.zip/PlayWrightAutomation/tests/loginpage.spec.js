
const {test} = require('@playwright/test');
const {expect} = require('@playwright/test');

test('Login to CEP', async ({ browser }) => {

  // Navigate to the login page
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto('https://cep.esim4devices.com');

  // Fill in username/email field
  await page.fill('input[name="username"]', 'your-username'); 
  // Replace with the actual selector (e.g., input#username, input[name="email"])

  // Fill in password field
  await page.fill('input[name="password"]', 'your-password'); 
  // Replace with the actual selector

  // Click the login button
  await page.click('button[type="submit"]'); 
  // Adjust selector if needed (e.g., text="Login")

  // Wait for navigation or dashboard element
  await page.waitForURL('**/dashboard'); 
  // Or wait for a specific element that appears after login
  await expect(page.locator('text=Welcome')).toBeVisible();
});
