let decimal:number = 6;
let hex:number = 0xf12001;
let binary:number = 0b1010;
let octal:number = 0o744;
let float:number = 6.14;
let color:string = "blue";
let fullname:string= 'John';
let age:number = 30;
let sentence:string = '${fullname}';
const names:string[] = [];
names.push('a');
const named:readonly string[] = ["a"];
const numbers=[1,2,3];
numbers.push(4);
let head:number = numbers[0];


let atuple: [string,boolean,number];
atuple = ["10",false,10];
atuple.push(20);
const cars: readonly[string,number,number] = ["H",10,10];
const car: {type:string,model:string,year:number}={type:"ford",model:"2016",year:10};
const casr = {type: "toyota"};
casr.type="f";
enum directions{
    North=1,
    East
}

let direction = directions.East;
enum statuscode {
    notfound = 200,
    success = 202,
    failure = 404
}
statuscode.success;

enum cardinal {
    North = 'North'
}










function cardinals(code: string|number){
    console.log("hello");
}
cardinals(404);