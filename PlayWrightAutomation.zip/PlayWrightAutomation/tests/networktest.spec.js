
const {test,expect} = require('@playwright/test');

test.beforeAll("Precondition",async({browser})=>{

    const browsercontext = await browser.newContext();
    const page = await browsercontext.newPage();
    await page.goto("https://rahulshettyacademy.com/client");
    await page.locator("#userEmail").fill("vyoesh@gmail.com");
    await page.locator("#userPassword").fill("Test@123");
    await page.locator("[type='submit']").click();
    await page.waitForLoadState('networkidle');

    await page.locator(".card-body b").first().waitFor;
    const content = await page.locator(".card-body b").allTextContents();

    await page.route("https://rahulshettyacademy.com/api/ecom/order/get-orders-details?id=*",
    route => route.continue({url: "https://rahulshettyacademy.com/api/ecom/order/get-orders-details?id=679f0d9de2b5443b1f434f0b"}
    ));

    //await page.locator("button:has-Text('View')").first().click();
    //await expect(page.locator("p.blink_me").last()).toHaveText("You are not authorize to view this order");
    //await page.route("**/*.{jpeg,jpg,png}",route=>route.abort());

    page.on('request',request=> console.log(request.url()));
    page.on('response',response=> console.log(response.url(),response.status()));

});