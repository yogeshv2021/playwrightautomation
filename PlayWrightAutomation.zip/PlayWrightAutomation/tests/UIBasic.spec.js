const {test} = require('@playwright/test');
const {expect} = require('@playwright/test');

/*
page.waitForloadState --> networkidle,load.
page.waitForResponse --> wait for the response
page.waitForRequest --> wait till request is sent.
page.waitForNavigation() --> until page navigation is complete.
page.waitForSelector()  --> wait for the elements to be visible.
page.waitForTimeout() -->default wait

*/

test('First Playwright test',async ({browser})=>{

    const context = await browser.newContext();
    const page = await context.newPage();
    const url = "https://rahulshettyacademy.com/loginpagePractise/";
    await page.goto(url);
    await context.addCookies([
        {
        name: "session",
        value: "1234",
        url: url
        }
    ])


    const username= page.locator('#username');
    const signin = page.locator("[name='signin']");
    const getcookies = context.cookies(url);
    const password = page.locator('#password');
    const cart = page.locator(".card-body a");
    
    await username.fill("yogesh");
    await password.fill("v");
    const dropdown = await page.locator("select.form-control");
    dropdown.selectOption("Teacher");
    await page.locator(".radiotextsty").nth(1).click();
    await page.locator("#okayBtn").click();
    //await expect (page.locator(".radiotextsty").last()).toBeChecked();
    //await page.locator('#terms').uncheck();
    //expect (await page.locator('#terms').isChecked()).toBeTruthy();

    await expect ( page.locator("[href='https://qasummit.org/']")).toHaveAttribute("class","blinkingText");


    /*
    await page.locator("[name='terms']").click();
    await signin.click();
    await page.locator("[style*='block']").textContent();
    await expect(page.locator("[style*='block']")).toContainText("Incorrect username/password.");

    await username.fill("");
    await username.fill("rahulshettyacademy");
    await password.fill("");
    await password.fill("learning");
    await signin.click();

    await expect(cart.nth(0)).toContainText("iphone X");

    let alltitles = await cart.allTextContents();
    await context.close();
    */

});


test('page Playwright test',async ({page})=>{
    let productname = 'IPHONE 13 PRO';
    let products = page.locator(".card-body");
    await page.goto("https://rahulshettyacademy.com/client");
    await page.locator("#userEmail").fill("vyoesh@gmail.com");
    await page.locator("#userPassword").fill("Test@123");
    await page.locator("[type='submit']").click();
    await page.locator(".card-body b").first().waitFor;//waiting for element to be displayed
    const content = await page.locator(".card-body b").allTextContents(); // to get contents
    let pcount = await products.count();
    for (let i=0;i<pcount;i++)
        {
         if (await products.nth(i).locator("b").textContent()===productname)
            {
                await products.nth(i).locator("text= Add To Cart").click();
                break;
            };
        };
    await page.locator("[routerlink*='cart']").click();
    await page.locator("div li").first().waitFor();
    expect (await page.locator("h3:has-text('IPHONE 13 PRO')").isVisible()).toBeTruthy();
    await page.locator("[type='button']").nth(1).click();
    await page.locator("[placeholder*='Country']").pressSequentially("ind");
    const dropdown= page.locator(".ta-results");
    await dropdown.waitFor();
    const options = await dropdown.locator("button").count();
    
    for (let i=0;i<options;i++){
        let text=await dropdown.locator("button").nth(i).textContent();
        console.log(text);
        if (text.trim()==="India"){
            await dropdown.locator("button").nth(i).click();
            break;
        }
    }

    await expect ( page.locator(".user__name [type='text']").first()).toHaveText("vyoesh@gmail.com");
    
    await page.locator('input.input.txt').nth(1).fill("503");
    await page.locator('input.input.txt').nth(2).fill("yogesh");
    await page.locator("[name='coupon']").fill("Coupon");

    const getexpirydate =page.locator('select.input');
    await getexpirydate.nth(0).selectOption("04");
    await getexpirydate.nth(1).selectOption("26");
   

    await page.locator('.action__submit').click();

    await expect (page.locator(".hero-primary")).toHaveText(" Thankyou for the order. ");
    const getorderid= await page.locator(".em-spacer-1 .ng-star-inserted").textContent();
    

    let newgetorderid = getorderid.split("|")[1].trim();
    console.log(newgetorderid);

    await page.locator(".em-spacer-1 [routerlink*='myorders']").click();
    const getviews = page.locator("tbody tr");
    const countview = await getviews.count();
    
    for(let i=0;i<countview;i++){
        if (await getviews.nth(i).locator("th").textContent()===newgetorderid){
            const getviewss = getviews.nth(i).locator("button").first();
            await getviewss.click();
            break;
        }
    }

    page.pause();
});

test('@special locators',async({page})=>{
    const url = "https://rahulshettyacademy.com/angularpractice/";
    await page.goto(url);
    await page.getByLabel("Check me out if you Love IceCreams!").check();
    await page.getByLabel("Gender").selectOption("Male");
    await page.getByLabel("Employed").check();
    await page.getByPlaceholder("Password").clear();
    await page.getByPlaceholder("Password").fill("Test@123");
    await page.getByRole("button",{name: "submit"}).click();
    const visible= page.getByText("Success! The Form has been submitted successfully!.").isVisible();
    if (visible){
       console.log("text is visible");
    }
    else{
        console.log("text is not visible");
    }
    await page.getByRole("Link",{name:"Shop"}).click();
    await page.locator("app-card").filter({hasText:'Nokia Edge'}).getByRole("button").click();
    await page.pause();
    
});

test('@child page',async ({browser})=>{
    const context = await browser.newContext();
    const page = await context.newPage();
    const username= page.locator('#username');
    const url = "https://rahulshettyacademy.com/loginpagePractise/";
    await page.goto(url);
    const documentclick = page.locator("[href*='documents-request']");

    const [newpage]= await Promise.all([
        context.waitForEvent('page'),documentclick.click(),
    ]);
    
    
    const gettext =await newpage.locator(".red").textContent();
    const getdomain = gettext.split("@")[1].split(" ")[0];
    await username.fill(getdomain);
    await page.pause();

});


test('new Playwright test',async ({page})=>{
    let productname = 'IPHONE 13 PRO';
    let products = page.locator(".card-body");
    await page.goto("https://rahulshettyacademy.com/client");
    await page.getByPlaceholder("email@example.com").fill("vyoesh@gmail.com");
    await page.getByPlaceholder("enter your passsword").fill("Test@123");
    await page.getByRole("button",({name:"Login"})).click();
    await page.locator(".card-body b").first().waitFor();
    await page.locator(".card-body").filter({hasText:productname}).getByRole("button",({name:"Add To Cart"})).click();
    
    await page.getByRole("listitem").getByRole("button",({name:"Cart"})).click();
    await page.locator("div li").first().waitFor();
    await expect (page.getByText(productname)).toBeVisible();
    await (page.getByRole("button").filter({hasText:"Checkout"})).click();
    
    await page.getByPlaceholder("Select Country").pressSequentially("ind");
    await page.getByRole("button",({name:"India"})).nth(1).click();
    
    await expect ( page.locator(".user__name [type='text']").first()).toHaveText("vyoesh@gmail.com");

    
    await page.locator('input.input.txt').nth(1).fill("503");
    await page.locator('input.input.txt').nth(2).fill("yogesh");
    await page.locator("[name='coupon']").fill("Coupon");

    const getexpirydate =page.locator('select.input');
    await getexpirydate.nth(0).selectOption("04");
    await getexpirydate.nth(1).selectOption("26");
    await page.getByText("PLACE ORDER").click()

    await expect (page.getByText("Thankyou for the order.")).toBeVisible();
    const getorderid= await page.locator(".em-spacer-1 .ng-star-inserted").textContent();
    console.log(getorderid);
    let newgetorderid = getorderid.split("|")[1].trim();
    console.log(newgetorderid);


    await page.getByText("Orders History Page").click();
    const getviews = page.locator("tbody tr");
    const countview = await getviews.count();

    for(let i=0;i<countview;i++){
        if (await getviews.nth(i).locator("th").textContent()===newgetorderid){
            const getviewss = getviews.nth(i).locator("button").first();
            await getviewss.click();
            break;
        }
    }

    page.pause();
});


test.only('@calendar validations',async ({page})=>{

    const month="1";
    const year ="2026";
    const date ="13";

    const list=[month,date,year];

    await page.goto("https://rahulshettyacademy.com/seleniumPractise/#/offers");
    await page.locator(".react-date-picker__inputGroup").click();
    await page.locator(".react-calendar__navigation__label").click();
    await page.locator(".react-calendar__navigation__label").click();
    await page.getByText(year).click();
    await page.locator(".react-calendar__year-view__months__month").nth(Number(month)-1).click();
    await page.locator("//abbr[text()='"+date+"']").click();
    
    const getelement = page.locator(".react-date-picker__inputGroup input");
    for (let i=0;i<getelement;i++){
        const value = page.locator(".react-date-picker__inputGroup input")[i].getAttribute("value");
        expect(value).toEqual(list[i]);
    }

    //expect(emonth).toEqual(list[0]);
    //expect(edate).toEqual(list[1]);
    //expect(eyear).toEqual(list[2]);

    await page.pause();
    
})


