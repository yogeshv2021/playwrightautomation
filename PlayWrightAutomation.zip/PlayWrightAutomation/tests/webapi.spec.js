const {test, expect, request} = require("@playwright/test");
const orderpayload= {orders:[{country:"India",productOrderedId:"6701364cae2afd4c0b90113c"}]}
const header = {"Authorization": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NzdhM2Y5MWUyYjU0NDNiMWYxMzZiNDkiLCJ1c2VyRW1haWwiOiJ2eW9lc2hAZ21haWwuY29tIiwidXNlck1vYmlsZSI6OTc5MDkxOTM0NCwidXNlclJvbGUiOiJjdXN0b21lciIsImlhdCI6MTczODQzMjAxMywiZXhwIjoxNzY5OTg5NjEzfQ.yoUKgs7riLqpi3YY86QHLAbUQ2pXdmDdCU4W0s9kkWY","Content-Type": "Application/json"};

const token="123";

//Login ApI
test.beforeAll(async()=>{
    const url = "https://rahulshettyacademy.com/client";
    const apicontext = await request.newContext();
    const getresponse = await apicontext.post(url,{data:{userEmail: 'vyoesh@gmail.com', userPassword: 'Test@123'}});
    expect(getresponse.ok()).toBeTruthy();
    expect(getresponse.status()).toBe(200);
    
    //const jsonresponse = await getresponse.json();
    //console.log(jsonresponse);
    //gettoken = jsonresponse.token;
    //console.log(gettoken);

    const orderresponse = apicontext.post("https://rahulshettyacademy.com/client/dashboard/myorders",
        {
            data: orderpayload,
            headers: header
        }
    );

    



});




test('Order',async ({page})=>{
    let productname = 'IPHONE 13 PRO';
    let products = page.locator(".card-body");
    
    page.addInitScript(value=>{
        window.localStorage.setItem("token",value);
    },token);

    await page.locator(".card-body b").first().waitFor;
    const content = await page.locator(".card-body b").allTextContents();
    let pcount = await products.count();
    for (let i=0;i<pcount;i++)
        {
         if (await products.nth(i).locator("b").textContent()===productname)
            {
                await products.nth(i).locator("text= Add To Cart").click();
                break;
            };
        };
    await page.locator("[routerlink*='cart']").click();
    await page.locator("div li").first().waitFor();
    expect (await page.locator("h3:has-text('IPHONE 13 PRO')").isVisible()).toBeTruthy();
    await page.locator("[type='button']").nth(1).click();
    await page.locator("[placeholder*='Country']").pressSequentially("ind");
    const dropdown= page.locator(".ta-results");
    await dropdown.waitFor();
    const options = await dropdown.locator("button").count();
    
    for (let i=0;i<options;i++){
        let text=await dropdown.locator("button").nth(i).textContent();
        console.log(text);
        if (text.trim()==="India"){
            await dropdown.locator("button").nth(i).click();
            break;
        }
    }

    await expect ( page.locator(".user__name [type='text']").first()).toHaveText("vyoesh@gmail.com");
    
    await page.locator('input.input.txt').nth(1).fill("503");
    await page.locator('input.input.txt').nth(2).fill("yogesh");
    await page.locator("[name='coupon']").fill("Coupon");

    const getexpirydate =page.locator('select.input');
    await getexpirydate.nth(0).selectOption("04");
    await getexpirydate.nth(1).selectOption("26");
   

    await page.locator('.action__submit').click();

    await expect (page.locator(".hero-primary")).toHaveText(" Thankyou for the order. ");
    const getorderid= await page.locator(".em-spacer-1 .ng-star-inserted").textContent();
    

    let newgetorderid = getorderid.split("|")[1].trim();
    console.log(newgetorderid);

    await page.locator(".em-spacer-1 [routerlink*='myorders']").click();
    const getviews = page.locator("tbody tr");
    const countview = await getviews.count();


    
    for(let i=0;i<countview;i++){
        if (await getviews.nth(i).locator("th").textContent()===newgetorderid){
            const getviewss = getviews.nth(i).locator("button").first();
            await getviewss.click();
            break;
        }
    }

    page.pause();
});



