"""
CEP Unified Inbox - Playwright Automation Script
URL: https://cep.esim4devices.com/portal/dashboard/home
Page: Unified Inbox (Inbox)

Requirements:
    pip install playwright
    playwright install chromium
"""

from playwright.sync_api import sync_playwright, Page, expect
import time
import asyncio
from datetime import datetime


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
BASE_URL    = "https://cep.esim4devices.com"
LOGIN_URL   = f"{BASE_URL}/portal/login"
INBOX_URL   = f"{BASE_URL}/portal/dashboard/inbox"
SIGN_IN_TEXT  = "Sign In"

EMAIL       = "sakthivel.vr@gmail.com"
PASSWORD    = "Sakthi@1234"

MSISDN      = "578489322771"
FROM_DATE   = "Mar 20, 2026"   # adjust format if the date picker needs it differently
TO_DATE     = "Mar 21, 2026"


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
async def login(page: Page) -> None:
    """Log in to the CEP portal."""
    print("[*] Navigating to login page...")
    page.goto(LOGIN_URL)
    page.wait_for_load_state("domcontentloaded")

    # Click login / submit
    page.click("button:has-text('Login')")
    page.wait_for_load_state("domcontentloaded")
    
    # Fill credentials
    page.fill("input[name='username']", EMAIL)
    page.fill("input[name='password']", PASSWORD)
    
    page.click("input[type='submit'],SIGN_IN_TEXT")
    page.wait_for_load_state("domcontentloaded")

    print(f"[✓] Logged in as {EMAIL}")


async def navigate_to_inbox(page: Page) -> None:
    
    """Navigate to the Unified Inbox page."""
    print("[*] Navigating to Unified Inbox...")

    # Try direct URL first
    page.goto(INBOX_URL)
    page.wait_for_load_state("load")

    # Fallback: click sidebar Inbox icon if redirect didn't work
    if "inbox" not in page.url.lower():
        left_sidebar = page.locator("xpath=//*[@class='bi bi-chevron-double-left']")
        print(left_sidebar.count())
        menu_click =  page.locator("xpath=//*[normalize-space(text())='UNIFIED INBOX']")

        if await left_sidebar.count() > 0:
            await menu_click.wait_for(state=visible)
            await menu_click.click()

        page.wait_for_load_state("domcontentloaded")

    print(f"[✓] On Inbox page: {page.url}")


async def fill_msisdn(page: Page, msisdn: str) -> None:
    """Enter the MSISDN / mobile number."""
    print(f"[*] Entering MSISDN: {msisdn}")
    msisdn_input = page.locator(
        "input[placeholder*='Mobile'], "
        "input[placeholder*='MSISDN'], "
        "input[placeholder*='Email ID'], "
        "input[placeholder*='Number']"
    ).first
    msisdn_input.clear()
    msisdn_input.fill(msisdn)
    print("[✓] MSISDN entered")


async def set_date_range(page: Page, from_date: str, to_date: str) -> None:
    """Set the From and To date in the date range picker."""
    print(f"[*] Setting date range: {from_date} → {to_date}")

    # Click the date range input to open the picker
    date_picker_trigger = page.locator(
        "input[placeholder*='Date'], "
        ".date-range, "
        "[class*='daterange'], "
        "[class*='DateRange'], "
        "input[readonly]"
    ).first
    date_picker_trigger.click()
    time.sleep(0.5)

    # Try to fill From date directly (works for some pickers)
    try:
        from_input = page.locator("input[name='start'], input[placeholder*='From'], input[placeholder*='Start']").first
        from_input.fill(from_date)
        to_input = page.locator("input[name='end'], input[placeholder*='To'], input[placeholder*='End']").first
        to_input.fill(to_date)
        print("[✓] Date range filled via direct inputs")
    except Exception:
        # Fallback: type into the combined range input
        date_picker_trigger.fill(f"{from_date} - {to_date}")
        print("[✓] Date range filled via combined input")

    # Press Enter or Tab to confirm
    page.keyboard.press("Enter")
    time.sleep(0.3)


async def click_search(page: Page) -> None:
    """Click the Search / Submit button."""
    print("[*] Clicking Search button...")
    page.click(
        "button:has-text('Search'), "
        "button:has-text('Submit'), "
        "button[type='submit']"
    )
    page.wait_for_load_state("networkidle")
    time.sleep(1)
    print("[✓] Search submitted")


async def extract_results(page: Page) -> list[dict]:
    """Extract voice call records from the results."""
    print("[*] Extracting results...")
    results = []

    # Wait for results to load
    page.wait_for_selector(".call-record, [class*='record'], [class*='call']", timeout=10000)

    # Get all call record cards
    records = page.locator("[class*='record'], [class*='call-item'], .card").all()

    for record in records:
        try:
            text = record.inner_text()
            results.append({"raw": text.strip()})
        except Exception:
            pass

    print(f"[✓] Extracted {len(results)} records")
    return results


async def take_screenshot(page: Page, name: str = "inbox_result") -> None:
    """Save a screenshot of the current page."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = f"{name}_{timestamp}.png"
    page.screenshot(path=path, full_page=True)
    print(f"[✓] Screenshot saved: {path}")


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def run_inbox_search(
    msisdn: str = MSISDN,
    from_date: str = FROM_DATE,
    to_date: str = TO_DATE,
    headless: bool = False,
    screenshot: bool = True,
) -> list[dict]:
    """
    Full automation: login → inbox → search → extract results.

    Args:
        msisdn:     Mobile number to search
        from_date:  Start date string (e.g. 'Mar 20, 2026')
        to_date:    End date string   (e.g. 'Mar 21, 2026')
        headless:   Run browser in headless mode (True = no UI)
        screenshot: Save a screenshot after search

    Returns:
        List of extracted call record dicts
    """
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless, slow_mo=300)
        context = browser.new_context(viewport={"width": 1440, "height": 900})
        page = context.new_page()

        try:
            login(page)
            navigate_to_inbox(page)
            fill_msisdn(page, msisdn)
            set_date_range(page, from_date, to_date)
            click_search(page)

            if screenshot:
                take_screenshot(page, "cep_inbox_result")

            results = await extract_results(page)
            return results

        except Exception as e:
            print(f"[✗] Error: {e}")
            page.screenshot(path="cep_error_screenshot.png")
            raise

        finally:
            browser.close()


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    records = run_inbox_search(
        msisdn    = MSISDN,
        from_date = FROM_DATE,
        to_date   = TO_DATE,
        headless  = False,   # Set True to run without browser UI
        screenshot= True,
    )

    print("\n── Results ──────────────────────────────")
    if records:
        for i, r in enumerate(records, 1):
            print(f"[{i}] {r}")
    else:
        print("No records found.")