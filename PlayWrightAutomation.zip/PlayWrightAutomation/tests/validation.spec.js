const {test} = require('@playwright/test')
const {expect} = require('@playwright/test')

test('Popup validations',async({page})=>{
     await page.goto("https://rahulshettyacademy.com/AutomationPractice/");
     await page.locator("#hide-textbox").click();
     await expect(page.locator("#displayed-text")).toBeHidden();
     page.on("dialog",dialog => dialog.accept()); // to get the dialog box
     await page.locator("#confirmbtn").click();
     await page.locator("#mousehover").hover();
     const framepage= page.frameLocator("#courses-iframe");
     await framepage.locator("li a[href*='lifetime-access']:visible").click(); //to check element is visible
     const getlement = await framepage.locator(".text h2").textContent(); //to get the text content
     console.log(getlement.split(" ")[1]);
     
});

