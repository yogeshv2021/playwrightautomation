const {expect,test} = require('@playwright/test');

class Orderdetail{

    constructor(page){
      this.page =page;
      this.contentlocator = this.page.locator(".em-spacer-1 .ng-star-inserted")
    }
  
    async verifydetails(){
        const getorderid= await this.contentlocator.textContent();
        let newgetorderid = getorderid.split("|")[1].trim();
        console.log(newgetorderid);
    
        await this.page.locator(".em-spacer-1 [routerlink*='myorders']").click();
        const getviews = this.page.locator("tbody tr");
        const countview = await getviews.count();
        
        for(let i=0;i<countview;i++){
            if (await getviews.nth(i).locator("th").textContent()===newgetorderid){
                const getviewss = getviews.nth(i).locator("button").first();
                await getviewss.click();
                break;
            }
        }

    }
}

module.exports = {Orderdetail};