const {test,expect}=require('@playwright/test');

class Dashboard{


    constructor(page){
      this.page =page;
      this.products = this.page.locator(".card-body");
      this.content = this.page.locator(".card-body b");
      this.countrylocator = this.page.locator("[placeholder*='Country']");

    }

    async searchandaddcart(productname){
        console.log(productname);
        const titles = await this.content.allTextContents();
        console.log(titles);

         let pcount = await this.products.count();
            for (let i=0;i<pcount;i++)
              {
                 if (await this.products.nth(i).locator("b").textContent()===productname)
                 {
                     await this.products.nth(i).locator("text= Add To Cart").click();
                     break;
                 };
              };
    }

    async cartpage(productname,country){

                await this.page.locator("[routerlink*='cart']").click();
                await this.page.locator("div li").first().waitFor();
                expect (await this.page.locator("h3:has-text('"+productname+"')").isVisible()).toBeTruthy();
                await this.page.locator("[type='button']").nth(1).click();
                await this.countrylocator.pressSequentially(country);
    }
  
  }
  
  module.exports= {Dashboard};