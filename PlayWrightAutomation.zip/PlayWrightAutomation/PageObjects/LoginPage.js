class LoginPage{


  constructor(page){
    this.page =page;
    this.username = this.page.locator("#userEmail")
    this.password = this.page.locator("#userPassword")
    this.submit = this.page.locator("[type='submit']");
  }

  async validlogin(username,password){
    await this.username.type(username);
    await this.password.type(password);
    await this.submit.click();
    await this.page.waitForLoadState('networkidle');
    await this.page.locator(".card-body b").first().waitFor;
  }

  async EnterLoginPage(){
    await  this.page.goto("https://rahulshettyacademy.com/client");  
  }
}

module.exports= {LoginPage};