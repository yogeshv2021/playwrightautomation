const {expect,test} = require('@playwright/test');


class CartDetail{

    constructor(page){
        this.page=page;
        this.inputtext = this.page.locator('input.input.txt');
    }

    async selectcountry(username,countryname){
        const dropdown= this.page.locator(".ta-results");
        await dropdown.waitFor();
        const options = await dropdown.locator("button").count();
        for (let i=0;i<options;i++){
            let text=await dropdown.locator("button").nth(i).textContent();
            console.log(text);
            if (text.trim()===countryname){
                await dropdown.locator("button").nth(i).click();
                break;
            }
        }
    
        await expect ( this.page.locator(".user__name [type='text']").first()).toHaveText(username);
    }
     
    async filldetails(name){
        await this.inputtext.nth(1).fill("503");
        await this.inputtext.nth(2).fill(name);
        await this.page.locator("[name='coupon']").fill("Coupon");
    
        const getexpirydate =this.page.locator('select.input');
        await getexpirydate.nth(0).selectOption("04");
        await getexpirydate.nth(1).selectOption("26");

        await this.page.locator('.action__submit').click();
        await expect (this.page.locator(".hero-primary")).toHaveText(" Thankyou for the order. ");
    }
    
};

module.exports = {CartDetail};