const {LoginPage} = require('./LoginPage');
const {Dashboard} = require('./Dashboard');
const {CartDetail} = require('./CartDetail');
const {Orderdetail} = require('./Orderdetail');

class PageObjectManager{

    constructor(page){

    this.page=page;
    this.loginPage = new LoginPage(this.page);
    this.dashboard = new Dashboard(this.page);
    this.cartDetail = new CartDetail(this.page);
    this.orderDetail = new Orderdetail(this.page);
   }

   getLoginpage(){
    return this.loginPage;

   }
   getdashboardpage(){
    return this.dashboard;

   }
   getcarddetailpage(){
    return this.cartDetail;

   }
   getorderdetailpage(){
    return this.orderDetail;

   }

}


module.exports = {PageObjectManager};