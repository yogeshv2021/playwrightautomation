const base = require('@playwright/test');

exports.commontest = base.test.extend(
    {
    fixturedata:{
        username : "vyoesh@gmail.com",
        password : "Test@123",
        productname : "IPHONE 13 PRO",
        name : "yogesh",
        country : "ind",
        countryname :"India"
    } 
  }
)


