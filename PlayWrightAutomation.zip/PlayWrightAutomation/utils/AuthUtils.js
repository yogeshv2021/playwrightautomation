const {expect} = require("@playwright/test");

class AuthUtils{

  constructor(apicontext,login,orderpayload,loginheader,header){
        this.apicontext = apicontext;
        this.login = login;
        this.orderpayload=orderpayload;
        this.loginheader=loginheader;
        this.header=header;
  }

  async getToken(){

    const url = "https://rahulshettyacademy.com/client/";
    const jsonresponse = await this.apicontext.post(url,{data:this.login,headers:this.loginheader}).then(function (response){
        console.log(response);
        return response.json();
    });
    //expect(getresponse.ok()).toBeTruthy();
    //expect(getresponse.status()).toBe(200);

    //const jsonresponse = await getresponse.json();
    console.log(jsonresponse);
    const gettoken = jsonresponse.token;
    console.log(gettoken);
    return token;

    }


    async createOrder(){

        let response = {};
            //response.token = await this.getToken();
            const getorderresponse = await this.apicontext.post("https://rahulshettyacademy.com/client/dashboard/myorders/",
                {
                    data: this.orderpayload,
                    headers: this.header
                }
            ).then(function (response){
                return response.json();
            });
        
            const newgetorderid = getorderresponse.orders(0);
            response.newgetorderid = newgetorderid;
            return newgetorderid;
    }

}

module.exports = {AuthUtils};