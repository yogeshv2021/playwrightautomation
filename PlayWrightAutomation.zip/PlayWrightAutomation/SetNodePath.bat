@echo off
set PATH=D:\node-v18.20.4\node-v18.20.4-win-x64\bin;%PATH%
node -v
npm install
pause