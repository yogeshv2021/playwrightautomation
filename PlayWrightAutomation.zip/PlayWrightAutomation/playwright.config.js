const { defineConfig, devices } = require('@playwright/test');

/**
 * @see https://playwright.dev/docs/test-configuration
 */
module.exports = defineConfig({
  login_url: 'https://cep.esim4devices.com/',
  signin_button: "xpath=//button[contains(normalize-space(.), 'Login')]",
  login_username: '#username',
  login_password: '#password',
  login_button: '#login',
  error_message_login: '#error',
  invalid_username: 'invalid@example.com',
  valid_password: 'ValidPassword123',
  incorrect_user_err_msg: 'Invalid email or password',
  testDir: './tests',
  timeout: 3 * 1000,
  expect: {
    timeout: 5000,
  },
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: 0,
  workers: 5,
  reporter: 'html',
  use: {
    trace: 'on-first-retry',
    testIdAttribute: 'data-pw', // configured data-testid
  },

  projects: [
    {
      name: 'chrome browser',
      use: {
        browserName: 'chromium',
        headless: false,
        video: 'retain-on-failure',
        screenshot: 'only-on-failure',
        trace: 'on',
      },
      launchOptions: {
        headless: false,
        executablePath:
          'C:\\Users\\yoge1542\\AppData\\Local\\ms-playwright\\chrome-win\\chrome.exe',
      },
    },
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    // Uncomment if you want Firefox or WebKit
    // {
    //   name: 'firefox',
    //   use: { ...devices['Desktop Firefox'] },
    // },
    // {
    //   name: 'webkit',
    //   use: { ...devices['Desktop Safari'] },
    // },
  ],
});
