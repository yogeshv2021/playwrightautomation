import { test, expect } from '@playwright/test';

const BASE_URL = 'https://rahulshettyacademy.com/seleniumPractise/#/';

test.describe('Discount Code Functionality', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    
    // Add multiple products to reach minimum discount threshold
    const addButtons = page.locator('button:has-text("ADD TO CART")');
    for (let i = 0; i < 4; i++) {
      await addButtons.nth(i).click();
      await page.waitForTimeout(200);
    }
    
    // Navigate to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
  });

  test('3.1: Apply valid discount code', async ({ page }) => {
    // Get original total
    const totalElement = page.locator('text=/Total|Subtotal|Amount/i, [class*="total"], td:has-text("$")').last();
    const originalTotal = await totalElement.textContent({ timeout: 2000 }).catch(() => '0');
    
    // Find discount code input
    const discountInput = page.locator('input[placeholder*="coupon"], input[placeholder*="Promo"], input[placeholder*="discount"], input[class*="promo"]').first();
    
    if (await discountInput.isVisible({ timeout: 1000 })) {
      // Enter valid discount code
      await discountInput.fill('rahulshettyacademy');
      
      // Find and click apply button
      const applyButton = page.locator('button:has-text("Apply"), button:has-text("APPLY"), [class*="apply-coupon"]').first();
      
      if (await applyButton.isVisible({ timeout: 1000 })) {
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Verify success message
        const successMsg = page.locator('text=/applied|success|discount/i, span.alert-success').first();
        expect(await successMsg.isVisible({ timeout: 2000 })).toBeTruthy();
      }
    } else {
      // Code might be applied inline or through different method
      expect(discountInput).toBeDefined();
    }
  });

  test('3.2: Apply invalid discount code', async ({ page }) => {
    // Find discount code input
    const discountInput = page.locator('input[placeholder*="coupon"], input[placeholder*="Promo"], input[placeholder*="discount"], input[class*="promo"]').first();
    
    if (await discountInput.isVisible({ timeout: 1000 })) {
      // Enter invalid code
      await discountInput.fill('INVALID123');
      
      // Find and click apply button
      const applyButton = page.locator('button:has-text("Apply"), button:has-text("APPLY"), [class*="apply-coupon"]').first();
      
      if (await applyButton.isVisible({ timeout: 1000 })) {
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Verify error message
        const errorMsg = page.locator('text=/invalid|error|not valid/i, span.alert-danger, .error-message').first();
        expect(await errorMsg.isVisible({ timeout: 2000 }).catch(() => false)).toBeTruthy();
      }
    }
  });

  test('3.3: Verify original code can only be applied once', async ({ page }) => {
    // Find discount code input
    const discountInput = page.locator('input[placeholder*="coupon"], input[placeholder*="Promo"], input[placeholder*="discount"], input[class*="promo"]').first();
    
    if (await discountInput.isVisible({ timeout: 1000 })) {
      // Apply valid code
      await discountInput.fill('rahulshettyacademy');
      
      const applyButton = page.locator('button:has-text("Apply"), button:has-text("APPLY"), [class*="apply-coupon"]').first();
      
      if (await applyButton.isVisible({ timeout: 1000 })) {
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Try to apply same code again
        await discountInput.fill('rahulshettyacademy');
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Should show error or disallow second application
        const errorMsg = page.locator('text=/already|applied|can only|once/i').first();
        const isErrorVisible = await errorMsg.isVisible({ timeout: 2000 }).catch(() => false);
        
        // Either shows error or button becomes disabled
        const isButtonDisabled = await applyButton.isDisabled({ timeout: 1000 }).catch(() => false);
        
        expect(isErrorVisible || isButtonDisabled).toBeTruthy();
      }
    }
  });

  test('3.4: Verify discount removed when code is cleared', async ({ page }) => {
    // Find discount code input
    const discountInput = page.locator('input[placeholder*="coupon"], input[placeholder*="Promo"], input[placeholder*="discount"], input[class*="promo"]').first();
    
    if (await discountInput.isVisible({ timeout: 1000 })) {
      // Apply valid code
      await discountInput.fill('rahulshettyacademy');
      
      const applyButton = page.locator('button:has-text("Apply"), button:has-text("APPLY"), [class*="apply-coupon"]').first();
      
      if (await applyButton.isVisible({ timeout: 1000 })) {
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Get discounted total
        const discountedTotal = page.locator('text=/Total|Subtotal|Amount/i, [class*="total"], td:has-text("$")').last();
        const discountedAmount = await discountedTotal.textContent({ timeout: 2000 }).catch(() => '0');
        
        // Clear the discount code field
        const clearButton = page.locator('button:has-text("Clear"), button:has-text("CLEAR"), [class*="clear"]').first();
        
        if (await clearButton.isVisible({ timeout: 1000 })) {
          await clearButton.click();
          await page.waitForTimeout(500);
          
          // Verify discount input is cleared
          const inputValue = await discountInput.inputValue();
          expect(inputValue).toBe('');
        }
      }
    }
  });

  test('3.5: Verify minimum cart value for discount', async ({ page }) => {
    // Clear existing cart
    const clearButton = page.locator('button:has-text("Clear"), button:has-text("CLEAR"), button.clear-cart').first();
    
    if (await clearButton.isVisible({ timeout: 1000 })) {
      await clearButton.click();
      await page.waitForTimeout(500);
    }
    
    // Go back home
    const homeButton = page.locator('a:has-text("Home"), a:has-text("Shop")').first();
    await homeButton.click({ timeout: 3000 }).catch(() => {
      page.reload();
    });
    
    await page.waitForLoadState('networkidle');
    
    // Add only 1-2 cheap items
    const addButtons = page.locator('button:has-text("ADD TO CART")');
    await addButtons.nth(0).click();
    
    // Go to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Try to apply discount with low cart value
    const discountInput = page.locator('input[placeholder*="coupon"], input[placeholder*="Promo"], input[placeholder*="discount"], input[class*="promo"]').first();
    
    if (await discountInput.isVisible({ timeout: 1000 })) {
      await discountInput.fill('rahulshettyacademy');
      
      const applyButton = page.locator('button:has-text("Apply"), button:has-text("APPLY"), [class*="apply-coupon"]').first();
      
      if (await applyButton.isVisible({ timeout: 1000 })) {
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Should show error about minimum value
        const errorMsg = page.locator('text=/minimum|required|more/i').first();
        const isErrorVisible = await errorMsg.isVisible({ timeout: 2000 }).catch(() => false);
        
        expect(isErrorVisible).toBeTruthy();
      }
    }
  });

  test('3.6: Verify discount calculation is accurate', async ({ page }) => {
    // Get original total
    const totalElements = page.locator('[class*="total"], text=/Total|Subtotal/i');
    const originalTotalText = await totalElements.last().textContent();
    const originalTotal = parseFloat(originalTotalText.replace(/[^\d.]/g, ''));
    
    // Apply discount
    const discountInput = page.locator('input[placeholder*="coupon"], input[placeholder*="Promo"], input[placeholder*="discount"], input[class*="promo"]').first();
    
    if (await discountInput.isVisible({ timeout: 1000 })) {
      await discountInput.fill('rahulshettyacademy');
      
      const applyButton = page.locator('button:has-text("Apply"), button:has-text("APPLY"), [class*="apply-coupon"]').first();
      
      if (await applyButton.isVisible({ timeout: 1000 })) {
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Get discounted total
        const discountedTotalText = await totalElements.last().textContent();
        const discountedTotal = parseFloat(discountedTotalText.replace(/[^\d.]/g, ''));
        
        // Discounted total should be less than original (assuming discount is for reduction)
        expect(discountedTotal).toBeLessThanOrEqual(originalTotal);
      }
    }
  });

  test('3.7: Verify discount percentage application', async ({ page }) => {
    // Get cart items and calculate expected total
    const rows = page.locator('table tbody tr');
    const rowCount = await rows.count();
    
    expect(rowCount).toBeGreaterThan(0);
    
    // Try to locate discount percentage display
    const discountDisplay = page.locator('[class*="discount"], text=/Off|%|Discount/').first();
    const isDiscountDisplayVisible = await discountDisplay.isVisible({ timeout: 1000 }).catch(() => false);
    
    const discountInput = page.locator('input[placeholder*="coupon"], input[placeholder*="Promo"], input[placeholder*="discount"], input[class*="promo"]').first();
    
    if (await discountInput.isVisible({ timeout: 1000 })) {
      await discountInput.fill('rahulshettyacademy');
      
      const applyButton = page.locator('button:has-text("Apply"), button:has-text("APPLY"), [class*="apply-coupon"]').first();
      
      if (await applyButton.isVisible({ timeout: 1000 })) {
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Discount should be applied
        const successMsg = page.locator('text=/applied|success/i').first();
        expect(await successMsg.isVisible({ timeout: 2000 })).toBeTruthy();
      }
    }
  });

  test('3.8: Verify discount removal from cart', async ({ page }) => {
    // Apply discount first
    const discountInput = page.locator('input[placeholder*="coupon"], input[placeholder*="Promo"], input[placeholder*="discount"], input[class*="promo"]').first();
    
    if (await discountInput.isVisible({ timeout: 1000 })) {
      await discountInput.fill('rahulshettyacademy');
      
      const applyButton = page.locator('button:has-text("Apply"), button:has-text("APPLY"), [class*="apply-coupon"]').first();
      
      if (await applyButton.isVisible({ timeout: 1000 })) {
        await applyButton.click();
        await page.waitForTimeout(1000);
        
        // Look for remove discount button
        const removeDiscountButton = page.locator('button:has-text("Remove"), i[class*="close"], svg + button').first();
        
        if (await removeDiscountButton.isVisible({ timeout: 1000 })) {
          await removeDiscountButton.click();
          await page.waitForTimeout(500);
          
          // Verify discount input is cleared
          const inputValue = await discountInput.inputValue();
          expect(inputValue).toBe('');
        }
      }
    }
  });
});
