import { test, expect } from '@playwright/test';

const BASE_URL = 'https://rahulshettyacademy.com/seleniumPractise/#/';

test.describe('Shopping Cart Functionality', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
  });

  test('2.1: Add single product to cart', async ({ page }) => {
    // Get first product add button
    const addButton = page.locator('button:has-text("ADD TO CART")').first();
    
    // Get product name for verification
    const productName = addButton.locator('..').locator('h4').first();
    const productNameText = await productName.textContent();
    
    // Click add to cart
    await addButton.click();
    
    // Verify success message or cart update
    const successMsg = page.locator('text=/added|success/i, span:has-text("✓")');
    await expect(successMsg).toBeVisible({ timeout: 3000 }).catch(() => {
      // Some apps don't show explicit message
    });
    
    // Navigate to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart-icon"]').first();
    await cartButton.click({ timeout: 3000 }).catch(async () => {
      // Try alternative cart selectors
      await page.locator('text=/cart/i').first().click();
    });
    
    await page.waitForLoadState('networkidle');
    
    // Verify product is in cart
    const cartItems = page.locator('table tbody tr, ul li, [class*="cart-item"]');
    const cartItemCount = await cartItems.count();
    expect(cartItemCount).toBeGreaterThan(0);
  });

  test('2.2: Add multiple different products to cart', async ({ page }) => {
    // Add first product
    let addButtons = page.locator('button:has-text("ADD TO CART")');
    let buttonCount = await addButtons.count();
    
    expect(buttonCount).toBeGreaterThanOrEqual(3);
    
    // Add 3 different products
    for (let i = 0; i < 3; i++) {
      const button = addButtons.nth(i);
      await button.click();
      await page.waitForTimeout(300);
    }
    
    // Navigate to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Verify multiple items in cart
    const cartItems = page.locator('table tbody tr, [class*="cart-item"]');
    const itemCount = await cartItems.count();
    
    expect(itemCount).toBeGreaterThanOrEqual(3);
  });

  test('2.3: Add same product multiple times', async ({ page }) => {
    // Find first product
    const firstAddButton = page.locator('button:has-text("ADD TO CART")').first();
    const productContainer = firstAddButton.locator('../..');
    const productName = await productContainer.locator('h4').textContent();
    
    // Add same product twice
    await firstAddButton.click();
    await page.waitForTimeout(200);
    await firstAddButton.click();
    
    // Go to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Find the product in cart and verify quantity increased
    const cartContainer = page.locator('table tbody tr, [class*="product-row"]');
    let foundProduct = false;
    
    const rows = page.locator('table tbody tr');
    const rowCount = await rows.count();
    
    // Check for quantity column
    for (let i = 0; i < rowCount; i++) {
      const row = rows.nth(i);
      const rowText = await row.textContent();
      
      if (rowText.includes(productName)) {
        foundProduct = true;
        // Check quantity - should be 2 or check if product appears twice
        break;
      }
    }
    
    expect(foundProduct).toBeTruthy();
  });

  test('2.4: Remove product from cart', async ({ page }) => {
    // Add a product
    const addButton = page.locator('button:has-text("ADD TO CART")').first();
    await addButton.click();
    
    // Go to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Get initial item count
    const initialItems = page.locator('table tbody tr, [class*="cart-item"]');
    const initialCount = await initialItems.count();
    
    expect(initialCount).toBeGreaterThan(0);
    
    // Find and click remove button
    const removeButton = page.locator('button:has-text("Remove"), button:has-text("Delete"), [class*="remove"]').first();
    
    if (await removeButton.isVisible({ timeout: 1000 })) {
      await removeButton.click();
      await page.waitForTimeout(500);
      
      // Verify item count decreased
      const afterItems = page.locator('table tbody tr, [class*="cart-item"]');
      const afterCount = await afterItems.count();
      
      expect(afterCount).toBeLessThan(initialCount);
    }
  });

  test('2.5: Update product quantity in cart', async ({ page }) => {
    // Add a product
    const addButton = page.locator('button:has-text("ADD TO CART")').first();
    await addButton.click();
    await page.waitForTimeout(200);
    await addButton.click();
    
    // Go to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Find quantity input or increment button
    const quantityInput = page.locator('input[type="number"], input.quantity').first();
    
    if (await quantityInput.isVisible({ timeout: 1000 })) {
      const currentValue = await quantityInput.inputValue();
      expect(currentValue).toBeTruthy();
      
      // Try to increase quantity
      await quantityInput.fill('5');
      await page.waitForTimeout(500);
      
      const newValue = await quantityInput.inputValue();
      expect(newValue).toBe('5');
    } else {
      // Look for +/- buttons
      const increaseButton = page.locator('button:has-text("+")').first();
      if (await increaseButton.isVisible({ timeout: 1000 })) {
        await increaseButton.click();
        expect(await increaseButton.isVisible()).toBeTruthy();
      }
    }
  });

  test('2.6: Clear entire cart', async ({ page }) => {
    // Add 3 products
    const addButtons = page.locator('button:has-text("ADD TO CART")');
    const count = await addButtons.count();
    
    for (let i = 0; i < Math.min(count, 3); i++) {
      await addButtons.nth(i).click();
      await page.waitForTimeout(200);
    }
    
    // Go to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Verify items exist
    let items = page.locator('table tbody tr, [class*="cart-item"]');
    const beforeClear = await items.count();
    expect(beforeClear).toBeGreaterThan(0);
    
    // Look for clear cart button
    const clearButton = page.locator('button:has-text("Clear"), button:has-text("CLEAR"), button.clear-cart').first();
    
    if (await clearButton.isVisible({ timeout: 1000 })) {
      await clearButton.click();
      await page.waitForTimeout(500);
      
      // Verify cart is empty
      items = page.locator('table tbody tr, [class*="cart-item"]');
      const afterClear = await items.count();
      expect(afterClear).toBe(0);
    }
  });

  test('2.7: Verify cart persists after page refresh', async ({ page }) => {
    // Add a product
    const addButton = page.locator('button:has-text("ADD TO CART")').first();
    await addButton.click();
    await page.waitForTimeout(500);
    
    // Refresh page
    await page.reload();
    await page.waitForLoadState('networkidle');
    
    // Go to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Verify item is still in cart
    const items = page.locator('table tbody tr, [class*="cart-item"]');
    const itemCount = await items.count();
    
    expect(itemCount).toBeGreaterThan(0);
  });

  test('2.8: Verify cart count increments correctly', async ({ page }) => {
    // Get initial cart count
    const cartIcon = page.locator('span:has-text("0"), [class*="cart-count"]').first();
    let initialCount = 0;
    
    try {
      const countText = await cartIcon.textContent();
      initialCount = parseInt(countText) || 0;
    } catch {
      initialCount = 0;
    }
    
    // Add product
    const addButton = page.locator('button:has-text("ADD TO CART")').first();
    await addButton.click();
    await page.waitForTimeout(500);
    
    // Check updated count
    const updatedCountText = await cartIcon.textContent({ timeout: 2000 }).catch(() => '0');
    const updatedCount = parseInt(updatedCountText) || 0;
    
    expect(updatedCount).toBeGreaterThanOrEqual(initialCount);
  });

  test('2.9: Verify cart total calculation', async ({ page }) => {
    // Add known products and verify total
    const addButtons = page.locator('button:has-text("ADD TO CART")');
    
    // Add first two products
    await addButtons.nth(0).click();
    await page.waitForTimeout(200);
    await addButtons.nth(1).click();
    
    // Go to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Look for total/subtotal
    const totalElement = page.locator('text=/Total|Subtotal|Amount/i, [class*="total"], td:has-text("$")').last();
    const totalText = await totalElement.textContent({ timeout: 2000 }).catch(() => '');
    
    expect(totalText).toBeTruthy();
  });

  test('2.10: Checkout button visible when items in cart', async ({ page }) => {
    // Add a product
    const addButton = page.locator('button:has-text("ADD TO CART")').first();
    await addButton.click();
    
    // Go to cart
    const cartButton = page.locator('a:has-text("Cart"), button:has-text("Cart"), [class*="cart"]').first();
    await cartButton.click();
    await page.waitForLoadState('networkidle');
    
    // Look for proceed/checkout button
    const checkoutButton = page.locator('button:has-text("Proceed"), button:has-text("Checkout"), button:has-text("Place Order")').first();
    
    expect(await checkoutButton.isVisible({ timeout: 2000 })).toBeTruthy();
  });
});
