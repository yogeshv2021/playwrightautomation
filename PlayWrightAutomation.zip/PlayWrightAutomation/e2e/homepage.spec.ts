import { test, expect } from '@playwright/test';

const BASE_URL = 'https://rahulshettyacademy.com/seleniumPractise/#/';

test.describe('Homepage and Product Catalog', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
  });

  test('1.1: Verify homepage loads successfully', async ({ page }) => {
    // Verify page loads without errors
    expect(page.url()).toContain('seleniumPractise');
    
    // Verify product grid is visible
    const productGrid = page.locator('div.products');
    await expect(productGrid).toBeVisible();
    
    // Verify at least one product exists
    const products = page.locator('div.product-action');
    const productCount = await products.count();
    expect(productCount).toBeGreaterThan(0);
    
    // Verify product elements have required children
    const firstProduct = products.first();
    await expect(firstProduct.locator('img')).toBeVisible();
    await expect(firstProduct.locator('button')).toContainText('ADD TO CART');
  });

  test('1.2: Verify product display and details', async ({ page }) => {
    // Get all products
    const products = page.locator('div.product-action');
    const productCount = await products.count();
    
    expect(productCount).toBeGreaterThan(0);
    
    // Verify each product has required elements
    for (let i = 0; i < Math.min(productCount, 5); i++) {
      const product = products.nth(i);
      
      // Check for product image
      const image = product.locator('img');
      await expect(image).toBeVisible();
      
      // Check for product name/price
      const productName = product.locator('h4');
      await expect(productName).toBeVisible();
      
      // Check for add to cart button
      const addButton = product.locator('button');
      await expect(addButton).toBeVisible();
      await expect(addButton).toContainText('ADD TO CART');
    }
  });

  test('1.3: Verify vegetable products are displayed', async ({ page }) => {
    // Verify multiple products are displayed
    const products = page.locator('div.product-action');
    const productCount = await products.count();
    
    // Should have at least 10 products as per test plan
    expect(productCount).toBeGreaterThanOrEqual(8);
    
    // Get product names and verify they are vegetable/fruit products
    const productNames = await page.locator('h4').allTextContents();
    expect(productNames.length).toBeGreaterThan(0);
    
    // Verify at least some known products exist
    const productText = productNames.join(' ').toUpperCase();
    expect(productText).toMatch(/BROCOLLI|CARROT|CAULIFLOWER|TOMATO|ONION/);
  });

  test('1.4: Verify navigation elements are present', async ({ page }) => {
    // Check for header/nav elements
    const header = page.locator('header, nav, .header');
    
    // Verify page title or key branding
    const pageTitle = page.locator('text=/greenKart|Home|Products/i');
    await expect(pageTitle).toBeVisible({ timeout: 2000 }).catch(() => {
      // Not all sites have same header structure
    });
  });

  test('1.5: Verify cart icon is accessible from homepage', async ({ page }) => {
    // Look for cart button/icon - common selectors
    const cartButton = page.locator('button:has-text("Cart"), a:has-text("Cart"), [class*="cart"]').first();
    
    // Try different common cart selectors
    const allElements = await page.locator('button, a, span').filter({ 
      has: page.locator('svg, i, text')
    }).count();
    
    expect(allElements).toBeGreaterThan(0);
  });

  test('1.6: Verify page load time is acceptable', async ({ page }) => {
    const startTime = Date.now();
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    const loadTime = Date.now() - startTime;
    
    // Page should load within 10 seconds (reasonable timeout)
    expect(loadTime).toBeLessThan(10000);
  });

  test('1.7: Verify no console errors on page load', async ({ page }) => {
    const consoleErrors: string[] = [];
    
    page.on('console', msg => {
      if (msg.type() === 'error') {
        consoleErrors.push(msg.text());
      }
    });
    
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    
    // Should have no critical console errors
    expect(consoleErrors.length).toBeLessThan(2);
  });

  test('1.8: Verify product images load correctly', async ({ page }) => {
    const images = page.locator('div.product-action img');
    const imageCount = await images.count();
    
    expect(imageCount).toBeGreaterThan(0);
    
    // Verify first few images are actually loaded
    for (let i = 0; i < Math.min(imageCount, 3); i++) {
      const image = images.nth(i);
      const isVisible = await image.isVisible();
      expect(isVisible).toBeTruthy();
    }
  });

  test('1.9: Verify responsive layout elements', async ({ page }) => {
    // Verify products container exists
    const productsContainer = page.locator('.products, [class*="product"]');
    await expect(productsContainer).toBeVisible();
    
    // Check viewport dimensions don't cause layout issues
    const { width } = page.viewportSize();
    expect(width).toBeGreaterThan(0);
  });

  test('1.10: Verify product prices are displayed', async ({ page }) => {
    // Look for price elements - common selectors
    const priceElements = page.locator('span:has-text("$"), .price, [class*="price"]').first();
    
    // Get product action containers
    const productActions = page.locator('div.product-action');
    const firstProduct = productActions.first();
    
    // Verify we can find some text content that looks like a price
    const productText = await firstProduct.textContent();
    expect(productText).toMatch(/\$|\d+/);
  });
});
